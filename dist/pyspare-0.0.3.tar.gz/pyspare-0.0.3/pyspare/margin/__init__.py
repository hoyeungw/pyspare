from .crostab_margin import crostab_margin
from .entries_margin import EntriesMargin, entries_margin
from .matrix_margin import MatrixMargin, matrix_margin
from .table_margin import table_margin
from .vector_margin import VectorMargin, vector_margin
