## pyspare
##### pretty print

### Usage
```python
from pyspare import deco
vect = [1,2,3]
print(deco(vect))
```