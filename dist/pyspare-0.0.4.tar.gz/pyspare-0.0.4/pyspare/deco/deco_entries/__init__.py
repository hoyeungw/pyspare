from .deco_dict import deco_dict
from .deco_entries import deco_entries
from .deco_object import deco_object
