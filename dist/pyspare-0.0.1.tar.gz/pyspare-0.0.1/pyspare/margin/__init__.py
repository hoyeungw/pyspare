from .entries_margin import EntriesMargin
from .matrix_margin import MatrixMargin
from .vector_margin import VectorMargin
