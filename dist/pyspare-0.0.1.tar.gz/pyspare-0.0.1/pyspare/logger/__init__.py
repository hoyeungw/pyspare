from pyspare.deco.deco_node import deco


def delog(o): print(deco(o))
